const Discord = require('discord.js')
const { QuickDB } = require('quick.db')
const db = new QuickDB()
const ms = require('ms')
const { ActivityType } = require('discord.js');
const config = require("./config.json")
const client = new Discord.Client({
  intents: [3243773]
});

module.exports = client

client.on('interactionCreate', (interaction) => {

  if (interaction.type === Discord.InteractionType.ApplicationCommand) {
    const cmd = client.slashCommands.get(interaction.commandName);
    if (!cmd) return interaction.reply(`Error`);
    interaction["member"] = interaction.guild.members.cache.get(interaction.user.id);
    cmd.run(client, interaction)

  }
})

client.on('ready', () => {
  console.log(`🔥 Estou online em ${client.user.username}!`);
  client.user.setPresence({
    activities: [{ name: `Sou um Bot feito para Atender Sugestões!.`, type: ActivityType.Playing }],
    status: 'idle',
  });
})

client.slashCommands = new Discord.Collection()
require('./handler')(client)
client.login(config.token)

const data = new Date()
const date = data.getHours().toLocaleString();

// EMOJIS | Coloca aqui os emojis que vc vai usar no sistema.

const calls_e_info = '🔵';
const calls_e_verify = '✅';
const calls_e_no = '🚫';
const calls_e_voice = '🎤';
const calls_e_danger = '⚠️';

 const calls_imagem_criada = 'https://cdn.discordapp.com/banners/1042440481755381800/8c99c5763235c760ea248ce8ba272495.png?size=2048'; // IMPORTANTE
 const calls_imagem_deletada = 'https://cdn.discordapp.com/banners/1042440481755381800/8c99c5763235c760ea248ce8ba272495.png?size=2048'; // IMPORTANTE
 const calls_imagem_geral = 'https://cdn.discordapp.com/banners/1042440481755381800/8c99c5763235c760ea248ce8ba272495.png?size=2048'; // IMPORTANTE


// CANAIS | Coloque os id's dos canais/categorias aqui.
const calls_config_cLogs = '1505735558373179514'; // Aonde vão as LOGS de calls criadas!
const calls_config_cPrincipal = '1505735549582053478'; // Canal principal do seu servidor

const calls_config_categoriaCalls = '1505735509773783091D'; // Categoria aonde vão ser criadas as calls

client.on("interactionCreate", async interaction => {
    const calls_logs = interaction.guild.channels.cache.get(calls_config_cLogs)
    const calls_principal = interaction.guild.channels.cache.get(calls_config_cPrincipal)

    const calls_bloqueada_botao = new Discord.ActionRowBuilder()
        .addComponents(
            new Discord.ButtonBuilder()
                .setCustomId("text_002")
                .setLabel('kn#9639 | Calls')
                .setDisabled(true)
                .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
            new Discord.ButtonBuilder()
                .setCustomId("text_003")
                .setLabel('🔊 Bloqueada')
                .setDisabled(true)
                .setStyle(Discord.ButtonStyle.Primary),
        )


    const calls_desbloqueada_botao = new Discord.ActionRowBuilder()
        .addComponents(
            new Discord.ButtonBuilder()
                .setCustomId("text_004")
                .setLabel('kn#9639 | Calls')
                .setDisabled(true)
                .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
            new Discord.ButtonBuilder()
                .setCustomId("text_005")
                .setLabel('🔊 Desbloqueada')
                .setDisabled(true)
                .setStyle(Discord.ButtonStyle.Primary),
        )

    const calls_criada_botao = new Discord.ActionRowBuilder()
        .addComponents(
            new Discord.ButtonBuilder()
                .setCustomId("text_006")
                .setLabel('kn#9639 | Calls')
                .setDisabled(true)
                .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
            new Discord.ButtonBuilder()
                .setCustomId("text_007")
                .setLabel('🔊 Criada')
                .setDisabled(true)
                .setStyle(Discord.ButtonStyle.Success),
        )
    const calls_deletada_botao = new Discord.ActionRowBuilder()
        .addComponents(
            new Discord.ButtonBuilder()
                .setCustomId("text_008")
                .setLabel('kn#9639 | Calls')
                .setDisabled(true)
                .setStyle(Discord.ButtonStyle.Secondary),
        )
        .addComponents(
            new Discord.ButtonBuilder()
                .setCustomId("text_009")
                .setLabel('🔊 Deletada')
                .setDisabled(true)
                .setStyle(Discord.ButtonStyle.Danger),
        )


    if (interaction.customId == 'btn-calls-criar') {
        const user = interaction.user;

        const canal_principal = await interaction.guild.channels.create({
            name: `🔒・${interaction.user.username}`,
            parent: calls_config_categoriaCalls,
            type: 2,
            permissionOverwrites: [
                {
                    id: interaction.guild.id,
                    deny: ["Connect"],
                },
                {
                    id: interaction.member,
                    allow: ["ViewChannel", "Stream", 'Connect', 'Speak', "SendMessages", "AddReactions", "AttachFiles", 'UseApplicationCommands', "MoveMembers"],
                },
            ],
        });

        const canal_aguardando = await interaction.guild.channels.create({
            name: `⌚・${interaction.user.username}`,
            parent: calls_config_categoriaCalls,
            type: 2,
            permissionOverwrites: [
                {
                    id: interaction.guild.id,
                    allow: ["Connect"],
                    deny: ["Stream", 'Speak', "SendMessages", "AddReactions", "AttachFiles", 'UseApplicationCommands'],
                },
                {
                    id: interaction.member,
                    allow: ["ViewChannel", 'Connect', 'Speak', "SendMessages", "AddReactions", 'UseApplicationCommands', "MoveMembers"],
                },
            ],
        });
        const criar_buttons = new Discord.ActionRowBuilder()
            .addComponents(
                new Discord.ButtonBuilder()
                    .setCustomId("text_001")
                    .setLabel('kn#9639 | Calls')
                    .setDisabled(true)
                    .setStyle(Discord.ButtonStyle.Success),
            )
            .addComponents(
                new Discord.ButtonBuilder()
                    .setLabel('🔊 Principal')
                    .setURL(`https://discord.com/channels/${interaction.guild.id}/${canal_principal.id}`)
                    .setStyle(Discord.ButtonStyle.Link),
            )
            .addComponents(
                new Discord.ButtonBuilder()
                    .setLabel('🔊 Aguardando')
                    .setURL(`https://discord.com/channels/${interaction.guild.id}/${canal_aguardando.id}`)
                    .setStyle(Discord.ButtonStyle.Link),
            );

        const log = new Discord.EmbedBuilder()
            .setAuthor({ name: `Call Criada` })
            .setDescription(`${calls_e_voice} **Call:** ${canal_principal} / ${canal_aguardando}\n${calls_e_info} **Call de:** ${interaction.user}`)
            .setThumbnail(calls_imagem_criada)
            .setFooter({ text: `${canal_principal.id} | ${interaction.user.id}` });

        calls_logs.send({ embeds: [log], components: [calls_criada_botao, criar_buttons] })

        interaction.reply({ content: `✅ ${interaction.user} **seu canal privado foi criado!** *Entre nos canais clicando nos botões abaixo.*\n**\`🔴\`** *Para liberar a entrada de seus amigos no seu canal, peça para eles entrarem no seu canal de* "**aguardando**", *depois disso basta move-los para seu canal principal.*`, components: [criar_buttons], ephemeral: true })

    } //

    if (interaction.customId == 'btn-calls_deletar_1') {
        let call_principal = client.channels.cache.find(c => c.name == `🔒・${interaction.user.username}`)
        let call_aguaradando = client.channels.cache.find(c => c.name == `⌚・${interaction.user.username}`)

        if (!call_principal) {
            console.log("Erro" + interaction.user.id + "    /    " + interaction.user.username)
            interaction.reply({ content: `❌`, ephemeral: true })
        }
        if (!call_aguaradando) {
            interaction.reply({ content: `${calls_e_no} ${interaction.user} **Gostaríamos de informar que a chamada solicitada foi removida com êxito do sistema. Agradecemos pela sua compreensão e colaboração em relação aos procedimentos de gerenciamento e organização das chamadas, e nos colocamos à disposição para quaisquer outras necessidades ou esclarecimentos adicionais**`, ephemeral: true }).then(() => {
                const embed_log = new Discord.EmbedBuilder()
                    .setAuthor({ name: `Call Deletada` })
                    .setDescription(`${calls_e_voice} **Call:** ${call_principal} / ${call_aguaradando}\n${calls_e_info} **Call de:** ${interaction.user}`)
                    .setThumbnail(calls_imagem_deletada)

                calls_logs.send({ embeds: [embed_log], components: [calls_deletada_botao] })
                call_principal.delete();
            })
        }
        else {
            interaction.reply({ content: `${calls_e_no} ${interaction.user} **Gostaríamos de informar que a chamada solicitada foi removida com êxito do sistema. Agradecemos pela sua compreensão e colaboração em relação aos procedimentos de gerenciamento e organização das chamadas, e nos colocamos à disposição para quaisquer outras necessidades ou esclarecimentos adicionais**`, ephemeral: true }).then(() => {
                const embed_log = new Discord.EmbedBuilder()
                    .setAuthor({ name: `Call Deletada` })
                    .setDescription(`${calls_e_voice} **Call:** ${call_principal} / ${call_aguaradando}\n${calls_e_info} **Call de:** ${interaction.user}`)
                    .setThumbnail(calls_imagem_deletada)

                calls_logs.send({ embeds: [embed_log], components: [calls_deletada_botao] })
                call_principal.delete();
                call_aguaradando.delete();
            })
        }
    } //

    if (interaction.customId == 'btn-calls_painelAvancado') {
        let call_aguaradando = client.channels.cache.find(c => c.name == `⌚・ ${interaction.user.username}`)
        let canal_principal = client.channels.cache.find(c => c.name == `🔒・ ${interaction.user.username}`)

        if (!canal_principal) {
            interaction.reply({ content: `${calls_e_no} ${interaction.user}, *você não pode usar este recurso no momento.* :(`, ephemeral: true })
        }
        else {
            const calls_painelAvancado_botao = new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId("btn-calls_block")
                        .setLabel('Bloquear')
                        .setEmoji(calls_e_no)
                        .setStyle(Discord.ButtonStyle.Danger),
                )
                .addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId("btn-calls_unblock")
                        .setLabel('Desbloquear')
                        .setEmoji(calls_e_verify)
                        .setStyle(Discord.ButtonStyle.Success),
                )

            interaction.reply({ components: [calls_painelAvancado_botao], ephemeral: true })
        }
    }

    if (interaction.customId == 'btn-calls_block') {
        let call_aguaradando = client.channels.cache.find(c => c.name == `⌚・${interaction.user.username}`)
        let canal_principal = client.channels.cache.find(c => c.name == `🔒・${interaction.user.username}`)

        if (!canal_principal && !call_aguaradando) {
            interaction.reply({ content: `${calls_e_no} ${interaction.user}, **você não criou uma call!**\n${calls_e_info} *Crie uma para ter acesso a este recurso.*`, ephemeral: true })
        }
        if (call_aguaradando) {
            interaction.reply({ content: `${calls_e_verify} **Sua call foi bloquada com sucesso!**\n${calls_e_info} *Agora seu canal de sala de espera foi deletado, portanto novos membros não poderão solicitar entrada e nem saber que você tem uma call privada criada.*`, ephemeral: true })
            call_aguaradando.delete()

            const log = new Discord.EmbedBuilder()
                .setAuthor({ name: `Call Bloqueada` })
                .setDescription(`${calls_e_voice} **Call:** ${canal_principal}\n${calls_e_info} **Call de:** ${interaction.user}`)
                .setThumbnail(calls_imagem_geral)
                .setFooter({ text: `${canal_principal.id} | ${interaction.user.id}` });
            calls_logs.send({ embeds: [log], components: [calls_bloqueada_botao] })
        }
    }
    if (interaction.customId == 'btn-calls_unblock') {
        let call_principal = client.channels.cache.find(c => c.name == `🔒・${interaction.user.username}`)
        let call_aguaradando = client.channels.cache.find(c => c.name == `⌚・${interaction.user.username}`)

        if (!call_principal) {
            interaction.reply({ content: `${calls_e_no} ${interaction.user} **você não criou uma call!** *Crie uma para ter acesso a este recurso.*`, ephemeral: true })
        }
        if (call_principal && !call_aguaradando) {
            const canal_aguardando = await interaction.guild.channels.create({
                name: `⌚・${interaction.user.username}`,
                parent: calls_config_categoriaCalls,
                type: 2,
                permissionOverwrites: [
                    {
                        id: interaction.guild.id,
                        allow: ["Connect"],
                        deny: ["Stream", 'Speak', "SendMessages", "AddReactions", "AttachFiles", 'UseApplicationCommands'],
                    },
                    {
                        id: interaction.member,
                        allow: ["ViewChannel", 'Connect', 'Speak', "SendMessages", "AddReactions", 'UseApplicationCommands', "MoveMembers"],
                    },
                ],
            });
            const desbloquear_buttons = new Discord.ActionRowBuilder()
                .addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId("text_001")
                        .setLabel('kn#9639 | Calls')
                        .setDisabled(true)
                        .setStyle(Discord.ButtonStyle.Success),
                )
                .addComponents(
                    new Discord.ButtonBuilder()
                        .setLabel('🔊 Aguardando')
                        .setURL(`https://discord.com/channels/${interaction.guild.id}/${canal_aguardando.id}`)
                        .setStyle(Discord.ButtonStyle.Link),
                )

            interaction.reply({ content: `${calls_e_verify} **Sua call foi desbloquada com sucesso!**\n${calls_e_info} *Seu canal de espera foi criado novamente e agora novos membros podem solicitar entrada.*`, components: [desbloquear_buttons], ephemeral: true })

            const log = new Discord.EmbedBuilder()
                .setAuthor({ name: `Call Desbloqueada` })
                .setDescription(`${calls_e_voice} **Call:** ${call_principal} / ${canal_aguardando}\n${calls_e_info} **Call de:** ${interaction.user}`)
                .setThumbnail(calls_imagem_geral)
                .setFooter({ text: `${call_principal.id} | ${interaction.user.id}` });
            calls_logs.send({ embeds: [log], components: [calls_desbloqueada_botao] })
        }

    }

})