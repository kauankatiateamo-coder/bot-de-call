const Discord = require("discord.js")

module.exports = {
    name: "admin-painelcalls",
    description: "🌎 [ADMIN] Enviar painel calls",
    type: Discord.ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(Discord.PermissionFlagsBits.Administrator)) return interaction.reply({ content: `❌ | Somente \`administradores\` podem usar este comando ${interaction.user}!` }).then(() => {
            setTimeout(() => {
                interaction.deleteReply()
            }, 15000)
        })
        else {

            const criar = new Discord.ButtonBuilder()
                .setCustomId("btn-calls-criar")
                .setLabel("Clique Aqui para criar sua Call Privada")
                .setEmoji(`✅`)
                .setStyle(Discord.ButtonStyle.Success)

            const deletar = new Discord.ButtonBuilder()
                .setCustomId("btn-calls_deletar_1")
                .setLabel("Clique Aqui para Deletar sua Call Privada")
                .setEmoji(`🗑️`)
                .setStyle(Discord.ButtonStyle.Danger)

            // const maisOpcoes = new Discord.ButtonBuilder()
            //     .setCustomId("btn-calls_painelAvancado")
            //     .setLabel("Mais Opções")
            //     .setEmoji(`ℹ`)
            //     .setStyle(Discord.ButtonStyle.Success)
            //     .setDisabled(false)

            const painel_calls = new Discord.ActionRowBuilder().addComponents(criar, deletar);

            const embed_calls = new Discord.EmbedBuilder()
            .setTitle(`\`🎤\` Utilize o painel disponibilizado para criar e gerenciar a sua chamada privada.`)
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setDescription(`**\`🎤\`** Após o procedimento, serão criados automaticamente dois canais de voz, sendo um identificado com o emoji de cadeado e o outro, com o emoji de relógio.\n**\`🎤\`** Para ingressar no canal principal, representado pelo emoji de cadeado, é necessário utilizar os botões disponíveis na mensagem de sucesso que será exibida após a criação do seu canal.\n**\`🎤\`** Seus amigos e convidados poderão solicitar acesso ao seu canal por meio do canal identificado com o símbolo de relógio.\n**\`🎤\`** Uma vez que um usuário ingressa neste canal, o proprietário da chamada privada tem a permissão para movê-lo da lista de aguardando para o canal privado.`)
            .setFooter({text: `Interaja com os botões abaixo para criar ou deletar a sua call!`, iconURL: interaction.guild.iconURL({ dinamyc: true }) })
            interaction.channel.send({ embeds: [embed_calls], components: [painel_calls]})
            interaction.reply({content: '✅ | A embed de painél de call já foi enviada com sucesso, agora todos podem criar suas calls!', ephemeral: true})
        }
    }
}