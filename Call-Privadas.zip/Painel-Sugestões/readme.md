# Bot de Call Privadas

# Configuração
Configure o config.json coloque seu TokenBot

# Instalação 
Requer Node v16.13.0 (LTS) 
Sbra o Terminal e digite npm i

# Inicialização
Após ter configurado tudo, abra o seu terminal e digite 
node .

Qualquer dúvidad chame: kn#9639
